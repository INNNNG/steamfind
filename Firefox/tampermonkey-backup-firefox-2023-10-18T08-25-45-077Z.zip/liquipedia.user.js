// ==UserScript==
// @name         liquipedia
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://liquipedia.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setTimeout(function(){
    document.getElementsByClassName('navigation-not-searchable')[0].style.display="none";
    document.getElementsByClassName('navigation-not-searchable')[1].style.display="none";
    document.getElementsByClassName('navigation-not-searchable')[3].style.display="none";
    },2000);
})();