// ==UserScript==
// @name         steamdb url
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://steamdb.info/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=steampowered.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setTimeout(function(){
        const linkcdn = document.getElementsByTagName('a');
        for (let i = 0; i < linkcdn.length; i++) {
            const href = linkcdn[i].getAttribute('href');
            if(href){
            if(!href.match("=")){
                linkcdn[i].setAttribute('href', href + '?_cdn=china_eccdnx');
            }else{
                linkcdn[i].setAttribute('href', href + '&_cdn=china_eccdnx');
            }
        }}
    },2000);
})();