// ==UserScript==
// @name         5866
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://uhzback.5866.com/pages/purchaseOrder.jsp?menuId=141
// @icon         https://www.google.com/s2/favicons?sz=64&domain=5866.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
 setTimeout(function(){
    document.getElementsByClassName('nav')[0].style.display="none";
    document.getElementsByClassName('sidebar')[0].style.display="none";
    document.getElementsByClassName('nav-tabs')[0].style.display="none";
    document.getElementsByClassName('table-a')[0].style.marginLeft="-180px";
    document.getElementsByClassName('acticle')[0].style.marginLeft=0;
                       },1500);
})();