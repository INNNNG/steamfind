// ==UserScript==
// @name         swy
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://yun.shunwang.com/static/index.html
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    setTimeout(function(){document.getElementsByClassName("el-menu-item is-active")[0].click();},200000);
})();