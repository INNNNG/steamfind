// ==UserScript==
// @name         steam url
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://store.steampowered.com/*
// @match        https://steamcommunity.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=steampowered.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    if (!window.location.href.match("china_eccdnx")){
        if(!window.location.href.match("=")){window.location.href = window.location.href+"?_cdn=china_eccdnx"}else{window.location.href = window.location.href+"&_cdn=china_eccdnx"}
    }
    setTimeout(function(){
        const linkcdn = document.getElementsByTagName('a');
        for (let i = 0; i < linkcdn.length; i++) {
            const href = linkcdn[i].getAttribute('href');
            if(href){
            if(!href.match("=")){
                linkcdn[i].setAttribute('href', href + '?_cdn=china_eccdnx');
            }else{
                linkcdn[i].setAttribute('href', href + '&_cdn=china_eccdnx');
            }
        }}
    },3000);
})();