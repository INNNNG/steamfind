// ==UserScript==
// @name         bbbb
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.bilibili.com/video/*
// @icon         none
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    setTimeout(function(){document.getElementsByClassName("bilibili-player-iconfont-widescreen-off")[0].click();},2000);
})();