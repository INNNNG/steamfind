// ==UserScript==
// @name         21.244
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://192.168.21.244/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=21.244
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.getElementsByClassName('list')[0].remove();
     var ss=document.getElementsByClassName('mreply').length;
for (var i=0;i<ss;i++)
{
    //document.getElementsByClassName('mreply')[i].style.display="none";
    document.getElementsByClassName('mtitle')[i].style.display="none";
    document.getElementsByClassName('smallavatar')[i].style.display="none";

}


})();