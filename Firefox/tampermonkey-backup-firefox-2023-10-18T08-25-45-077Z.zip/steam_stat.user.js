// ==UserScript==
// @name         steam_stat
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://partner.steamgames.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setTimeout(function(){
        document.getElementsByTagName('h2')[0].addEventListener("click",function ddd(){
    document.getElementById('licenseTable').parentNode.removeChild(document.getElementById('licenseTable'));
     a1=Number('0');
     pubg=Number('0');
    var s1=Number(document.getElementById("appTable").getElementsByClassName("landingTable").length-4);
    var s2=Number(document.getElementById("appTable").getElementsByClassName("icon_check").length);
    var s3=Number(document.getElementById("licenseTable").getElementsByClassName("indent").length-35);
    if(document.getElementById("app_578080")!=null){var pubg=Number(document.getElementById("app_578080").getElementsByClassName("td")[2].textContent);}
    if(document.getElementById("app_1172470")!=null){var a1=Number(document.getElementById("app_1172470").getElementsByClassName("td")[2].textContent);}
    var cs=Number(document.getElementById("app_730").getElementsByClassName("td")[2].textContent);
    var d2=Number(document.getElementById("app_570").getElementsByClassName("td")[2].textContent);
    var ttt=Number(cs+d2);
    var tt=Number(ttt+pubg+a1);
    //document.getElementsByTagName('h2')[0].textContent=('['+s2+'] | '+s3+' = '+s1+' + '+tt);
    document.getElementsByTagName('h2')[0].textContent=(s3+'　'+s1+'　　　　　PUBG　　APEX　　'+ttt+'　　CS　　DO');
    document.getElementsByTagName('h2')[1].textContent=(' ['+s2+']　 '+tt+'　 　　　　'+pubg+'　　　　'+a1+'　   　 　　 　 '+cs+'　　 '+d2);
    document.getElementById('applicationTable').getElementsByClassName('tr').length;
    });
    },1500);
})();