// ==UserScript==
// @name         del curator
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://store.steampowered.com/curator/29660712-%25E5%258D%2597-%25E4%25BA%25AC/admin/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=steampowered.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

})();


  //  fetch("https://store.steampowered.com/curator/29660712-%25E5%258D%2597-%25E4%25BA%25AC/admin/ajaxdeletereview/", {
    "credentials": "include",
    "headers": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "no-cors",
        "Sec-Fetch-Site": "same-origin",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache"
    },
    "referrer": "https://store.steampowered.com/curator/29660712-%25E5%258D%2597-%25E4%25BA%25AC/admin/reviews_manage",
   // "body": "appid=38410&sessionid=2bbe113ccd81d3bd3e931a78",
    "method": "POST",
    "mode": "cors"
    });